You need to have the following libraries
import numpy as np
import pandas as pd
import plotly.graph_objects as go

Specify number of klusters for K means algorithm to run by going down the code unill you see
5 lines of #'s 
then change:
kluster =  to specify the # of clusters you want to have


there are times when it seems that when calculating a centroid it sometimes encounters an error where the index goes out of bounds
and have not been able to fix this problem but if this happens just rerun it and should be fine only happens occasionally.