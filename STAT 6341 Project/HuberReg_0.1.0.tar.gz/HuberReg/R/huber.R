#' Huber Regression
#'
#' @description Computes linear regression parameters given the huber loss function
#' @param X nxp Covariate matrix
#' @param y nx1 Response Vector
#' @param M double Huber residual threshold (default is IQR(y)/10)
#' @param intercept bool to include intercept (default is TRUE)
#' @param beta_init (p+1) vector of initial starting values for beta vector (default is (p+1) vector of zeros)
#' @param W_init nxn diagonal matrix of initial starting values for W matrix (default nxn identity matrix)
#' @param scalex bool indicate whether to scale covariate matrix X (default is FALSE)
#' @param scaley bool indicate whether to scale response vector y (default is FALSE)
#' @param maxiter integer max number of iterations (default is 1000)
#' @param tol double tolerance of convergence for huber loss function
#' @param trace bool whether convergence information is printed (default is TRUE)
#' @return  cd_huber returns a list of beta, weights, residuals, and table
#' \item{beta: Vector of beta coefficients}
#' \item{W: Vector of weights}
#' \item{residual: Vector of residuals}
#' @description
#' Implements a coordinate descent algorithm for huber regression
#' @examples
#' set.seed(7330)
#' n <- 100; beta <- c(1,2)
#' X <- rnorm(n)
#' y <- cbind(1,X) %*% beta + rnorm(100)
#' cd_huber(X=X,y=y)$beta

cd_huber <- function(X,y,M = NULL,intercept = TRUE,beta_init = NULL, W_init = NULL,scalex = FALSE,scaley = FALSE,maxiter = 1000,tol = 1e-5,trace = TRUE) {
  # scale X
  if(scalex){
    X <- scale(X)
  }
  # scale y
  if(scaley) {
    y <- scale(y)
  }

  # if we use intercept add a column of 1's
  if(intercept) {
    X <- cbind(1,X)
  }

  if (is.null(beta_init)) { # if the initial values of beta_init = null then initialize beta to zeros
    beta <- rep(0,dim(X)[2])
  }
  else { # else initialize beta to initial value provided
    beta <- beta_init
  }

  if (is.null(W_init)) { # if the initial values of W_init = null then initialize weight matrix to ones
    W <- diag(dim(X)[1])
  }
  else { # else initialize Weight matrix to initial value provided
    W <- W_init
  }
  if(is.null(M)){
    M <- stats::IQR(y)/10
  }
  #initialize
  n <- dim(X)[1]
  p <- dim(X)[2]
  resid <- numeric(n)


  beta <- cdhubercpp(X = X,y = y,W = W,M = M,lambda = 0,beta = beta,lasso = FALSE,
                     intercept = intercept,resid = resid,maxiter = maxiter,tol = tol,trace = trace)
  resid <- resids(X,y,beta)
  W <- weightc(resid,M)

  return(list(beta = beta,W = diag(W),residual = resid))
}




#' Huber Lasso Regression
#'
#' @description Computes linear regression parameters given the huber loss function with penalized Lasso
#' @param X nxp Covariate matrix
#' @param y nx1 Response Vector
#' @param lambda double controls the amount of penalty applied to parameters
#' @param M double Huber residual threshold (default is IQR(y)/10)
#' @param intercept bool to include intercept (default is TRUE)
#' @param beta_init (p+1) vector of initial starting values for beta vector (default is (p+1) vector of zeros)
#' @param W_init nxn diagonal matrix of initial starting values for W matrix (default nxn identity matrix)
#' @param scalex bool indicate whether to scale covariate matrix X (default is FALSE)
#' @param scaley bool indicate whether to scale response vector y (default is FALSE)
#' @param maxiter integer max number of iterations (default is 1000)
#' @param tol double tolerance of convergence for huber loss function
#' @param trace bool whether convergence information is printed (default is TRUE)
#' @return  cd_huber_lasso returns a list of beta, weights, and residuals
#' \item{beta: Vector of beta coefficients}
#' \item{W: Vector of weights}
#' \item{residual: Vector of residuals}
#' @description
#' Implements a coordinate descent algorithm for huber Lasso regression
#'
#' @examples
#' set.seed(6341)
#' n <- 200; p <- 20; rho <- 0.5; q = 11
#' lambda <- 0.1
#' beta <-  c(seq(0,1,.1),rep(0,p-q))
#' Sigma <- rho^abs(outer(1:(p-1),1:(p-1),"-"))
#' X <- mvtnorm::rmvnorm(n, rep(0, p-1), Sigma)
#' y <- cbind(1,X) %*% beta + rnorm(n)
#' cd_huber_lasso(X = X,y = y, lambda = lambda)$beta
#'
cd_huber_lasso <- function(X,y,lambda,M = NULL,intercept = TRUE,beta_init = NULL, W_init = NULL,scalex = FALSE,scaley = FALSE,maxiter = 1000,tol = 1e-5,trace = TRUE) {
  # scale X
  if(scalex){
    X <- scale(X)
  }
  # scale y
  if(scaley) {
    y <- scale(y)
  }

  # if we use intercept add a column of 1's
  if(intercept) {
    X <- cbind(1,X)
  }

  if (is.null(beta_init)) { # if the initial values of beta_init = null then initialize beta to zeros
    beta <- rep(0,dim(X)[2])
  }
  else { # else initialize beta to initial value provided
    beta <- beta_init
  }

  if (is.null(W_init)) { # if the initial values of W_init = null then initialize weight matrix to ones
    W <- diag(dim(X)[1])
  }
  else { # else initialize Weight matrix to initial value provided
    W <- W_init
  }
  if(is.null(M)){
    M <- stats::IQR(y)/10
  }
  #initialize
  n <- dim(X)[1]
  p <- dim(X)[2]
  resid <- numeric(n)

  beta <- cdhubercpp(X = X,y = y,W = W,M = M,lambda = lambda,beta = beta,lasso = TRUE,intercept = intercept,resid = resid,maxiter = maxiter,tol = tol,trace = trace)
  resid <- resids(X = X,y = y,beta = beta)
  W <- weightc(resid = resid,M = M)


  return(list(beta = beta,W = diag(W),residual = resid))
}



#' Huber Lasso Coefficients Plot
#'
#' @description Computes linear regression parameters given the huber loss function with penalized Lasso
#' @param data list with elements X and y where X is a nxp matrix and y is vector of size n
#' @param M double Huber residual threshold (default is IQR(y)/10)
#' @param lambda.list vector of lambdas
#' @param beta_init (p+1) vector of initial starting values for beta vector (default is (p+1) vector of zeros)
#' @param W_init nxn diagonal matrix of initial starting values for W matrix (default nxn identity matrix)
#' @param scalex bool indicate whether to scale covariate matrix X (default is FALSE)
#' @param scaley bool indicate whether to scale response vector y (default is FALSE)
#' @param intercept bool to include intercept (default is TRUE)
#' @param tol double tolerance of convergence for huber loss function
#' @param maxiter integer max number of iterations (default is 1000)
#' @param trace bool whether convergence information is printed (default is TRUE)
#' @return  plot_cd_huber_lasso returns a ggplot fig of coef
#' \item{fig: ggplot figure of coefficients}
#' @description
#' plots coefficients of huber Lasso regression for each lambda
#'
#' @examples
#' set.seed(6341)
#' n <- 200; p <- 20; rho <- 0.5; q = 11
#' lambda.list <- sqrt(log(p)/n)*exp( seq(from = -10,to =10)/6)
#' beta <-  c(seq(0,1,.1),rep(0,p-q))
#' Sigma <- rho^abs(outer(1:(p-1),1:(p-1),"-"))
#' X <- mvtnorm::rmvnorm(n, rep(0, p-1), Sigma)
#' y <- cbind(1,X) %*% beta + rnorm(n)
#' data <- list(X = X,y = y)
#' plot_cd_huber_Lasso(data = data, lambda.list = lambda.list,trace =FALSE)
#'
#'
plot_cd_huber_Lasso <- function(data,M = NULL, lambda.list,beta_init = NULL, W_init = NULL, scalex = FALSE, scaley = FALSE, intercept=TRUE, tol=1e-5, maxiter=1000,trace = TRUE){
  # initialize pand beta matrix
  p <- dim(data$X)[2]

  beta <- matrix(0,nrow = length(lambda.list),ncol = p +1)

  for (i in 1:length(lambda.list)) {
    # calcs the beta coeff for each lambda and stores the vector rowwise
    beta[i,] <- cd_huber_lasso(data$X,data$y,M = M, lambda = lambda.list[i],
                               intercept = intercept, beta_init = beta_init, W_init = W_init,
                               scalex = scalex, scaley = scaley,
                               tol = tol, maxiter = maxiter, trace = trace)$beta

  }
  # creates a data frame for plotting saves lambda as log lambda to have a better visualization
  df <- data.frame(lambda = log(lambda.list),beta)
  if(intercept) {
    df <- df[,-2]
    colnames(df) <- c("Loglambda",paste("Beta",1:p))
  }
  else{
    colnames(df) <- c("Loglambda",paste("Beta",1:p))
  }

  # melt the dataframe so we can plot the coeff together in one plot
  data_long <- reshape2::melt(df, id = "Loglambda")
  # creates the coeff plot using ggplot
  fig <- ggplot2::ggplot(data_long,ggplot2::aes(x=Loglambda,y = value,color = variable, show.legend = FALSE)) +
    ggplot2::geom_line(show.legend = FALSE) +
    ggplot2::xlab("Log Lambda") +
    ggplot2::ylab("Coefficients") +
    ggplot2::ggtitle("Coeffecient Profile Plot")
  return(fig)
}






#' Cross Validation of Huber Lasso Regression
#'
#' @description Preforms crossvalidation
#' @param data list with elements X and y where X is a nxp matrix and y is vector of size n
#' @param M double Huber residual threshold (default is IQR(y)/10)
#' @param lambda.list vector of lambdas
#' @param kfold integer number of folds of cross validation (default is 5)
#' @param intercept bool to include intercept (default is TRUE)
#' @param beta_init (p+1) vector of initial starting values for beta vector (default is (p+1) vector of zeros)
#' @param W_init nxn diagonal matrix of initial starting values for W matrix (default nxn identity matrix)
#' @param scalex bool indicate whether to scale covariate matrix X (default is FALSE)
#' @param scaley bool indicate whether to scale response vector y (default is FALSE)
#' @param tol double tolerance of convergence for huber loss function
#' @param maxiter integer max number of iterations (default is 1000)
#' @param plot bool indicate whether to plot loss function and beta min and beta 1 standard error from beta min (default is TRUE)
#' @param trace bool whether convergence information is printed (default is TRUE)
#' @return  cv.lasso.huber returns lambda.list, loss, M for each fold, lambda.min, beta_min, lambda.1se, beta_1se, fig
#' \item{lambda.list: List of the lambdas used in cross validation}
#' \item{M: The M computed and used for each fold of the trainset}
#' \item{lam.min: lambda value with the minimum huber loss}
#' \item{beta_min: beta coefficients calculated using the lam.min value}
#' \item{lam.1se: largest lambda with a huber loss within 1 standard error of lam.min's huber loss}
#' \item{beta_1se: beta coefficients calculated using the lam.1se value}
#' \item{fig: ggplot figure that visualizes the huber loss function against lambda}
#' @description
#' uses cross validation to find best lambda via huber loss
#'
#' @examples
#' set.seed(6341)
#' n <- 100; p <- 30; rho <- 0.5; q = 11
#' lambda.list <- sqrt(log(p)/n)*exp( seq(from = -15,to =-5)/6)
#' beta <-  c(seq(0,1,.1),rep(0,p-q))
#' Sigma <- rho^abs(outer(1:(p-1),1:(p-1),"-"))
#' X <- mvtnorm::rmvnorm(n, rep(0, p-1), Sigma)
#' y <- cbind(1,X) %*% beta + rnorm(n)
#' data <- list(X = X,y = y)
#' fit <-cv.lasso.huber(data = data, lambda.list = lambda.list,scalex = TRUE,scaley = TRUE)
#' fit$fig
#'
#'

cv.lasso.huber <- function(data, M = NULL,lambda.list, kfold = 5, intercept = TRUE,
                           beta_init = NULL, W_init = NULL, scalex = FALSE, scaley = FALSE, tol = 1e-5, maxiter = 1000, plot = TRUE,trace = FALSE){
  # data is in the list form (X,y) ie the outcome vector is the last element
  n <- dim(data$X)[1]
  nlambda <- length(lambda.list)
  loss <- rep(0, nlambda)
  m <- numeric(kfold)

  # creates a random vector of kfold groups of of equal number and if modulus
  # sample size kgroups is not zero randomly assigns the few remaining observations to a group
  # then it adds it as the first column in the data matrix
  fold <- cbind(1:n,c(sample(rep(1:kfold,each= n/kfold)),sample(1:kfold,n %% kfold)))


  for (k in 1:kfold) {
    # sets the test set as current kfold set
    testset_X <- data$X[fold[fold[,2] == k,][,1],]
    testset_y <- data$y[fold[fold[,2] == k,][,1],]
    # sets the train set as the current (k-1) fold set
    trainset_X <- data$X[fold[fold[,2] != k,][,1],]
    trainset_y <- data$y[fold[fold[,2] != k,][,1],]

    # scale X
    if(scalex){
      testset_X <- scale(testset_X)
      trainset_X <- scale(trainset_X)
    }
    # scale y
    if(scaley) {
      testset_y <- scale(testset_y)
      trainset_y <- scale(trainset_y)
    }

    if(is.null(M)){
      M <- stats::IQR(trainset_y)/10
    }
    m[k] <- M
    for (j in 1:nlambda) {
      #calculates the beta Lasso for the training data and lambda list
      beta <- cd_huber_lasso(X = trainset_X,y = trainset_y,M = M, lambda = lambda.list[j],
                             intercept = intercept,beta_init = beta_init, W_init = W_init,
                             scalex = FALSE, scaley = FALSE,
                             tol = tol, maxiter = maxiter, trace = trace)$beta
      # uses the test data set to and the beta lasso to the get the test predictions
      if(intercept){
        yhat <- as.matrix(cbind(1,testset_X)) %*% as.matrix(beta)
      }
      else {
        yhat <- as.matrix(testset_X) %*% as.matrix(beta)
      }
      #print(paste("lambda",lambda.list[j]))
      #print(paste("beta",beta))
      # adds sse[j] to mse[j] so we can divide later to get the mse for each lambda
      resid <- testset_y - yhat
      temp <- lossc(resid,M)
      loss[j] <- loss[j] + temp
    }
  }

  # averages the mse's over the number of kfolds for each lambda and saves the result in a dataframe
  #loss <- loss/n


  # finds and saves the smallest lambda value
  #lam.min <- avgMSE[[which.min(avgMSE$Avg_MSE),1]]
  lam.min <- lambda.list[which.min(loss)]

  lam.1se <- max(lambda.list[loss <= min(loss)+sd(loss)])


  # calculates the min beta from lam.min and input data
  beta_min <-cd_huber_lasso(X = data$X, y = data$y, M = M,lambda = lam.min,
                            intercept = intercept, beta_init = beta_init, W_init = W_init,
                            scalex = scalex, scaley = scaley,
                            tol = tol, maxiter = maxiter, trace = FALSE)$beta

  # calculates the beta for the lambda 1 standard deviation from the min lambda
  beta_1se <-cd_huber_lasso(X = data$X, y = data$y, M = M,lambda = lam.1se,
                            intercept = intercept, beta_init = beta_init, W_init = W_init,
                            scalex = scalex, scaley = scaley,
                            tol = tol, maxiter = maxiter, trace = FALSE)$beta

  if(plot){

    avgloss <- data.frame(lambda.list,loss)
    colnames(avgloss) <- c("Lambda","Avg_loss")

    # this is used to add visual label of lam.min and lam_1se
    plotstat <- rbind(avgloss[avgloss$Lambda == lam.min,],avgloss[avgloss$Lambda == lam.1se,])

    # ggplot stuff
    fig <- ggplot2::ggplot(avgloss,ggplot2::aes(x = Lambda,y = Avg_loss)) +
      ggplot2::geom_line(color = "#0099f9") +
      # adds vertical lines for lam.min and lam_1se
      ggplot2::geom_vline(ggplot2::aes(xintercept=lam.min,color = "Lambda.min"),linetype="dashed") +
      ggplot2::geom_vline(ggplot2::aes(xintercept=lam.1se,color = "Lambda.1se"),linetype="dashed") +
      # sets colors of vertical lines
      ggplot2::scale_color_manual(values = c("Lambda.min" = "purple","Lambda.1se" = "salmon")) +
      # labels the values for the 2 pointing at the point it represents
      ggrepel::geom_label_repel(data = plotstat,
                                ggplot2::aes( label = c(paste("Min Lambda =",round(lam.min,5)),paste("1se Lambda =",round(lam.1se,5))) ),
                                nudge_y       =  - .01,
                                size          = 4,
                                box.padding   = 0.5,
                                point.padding = 0.5,
                                force         = 10,
                                segment.size  = 0.2,
                                segment.color = "grey50",
                                direction     = "x",
                                alpha = 0.6) +

      ggplot2::labs(
        caption = "Min Lambda represents the tuning parameter lambda with the smallest Total loss \nfound via K-fold CV. \n1se Lambda represents the largest lambda within one standard error from \nthe Minimun lambda's Total loss.",
        title = "Performance of Tuning Parameter Lambda",
        y = "Total loss"
      )
  }
  else {
    fig <- NULL
  }



  return(list(lambda.list = lambda.list, loss = loss, M = m,
              lam.min = lam.min, beta_min = beta_min,
              lam.1se = lam.1se, beta_1se = beta_1se,
              fig = fig))
}


#' Data Generation
#'
#' @description Generates data with outliers defined by parameters pr and fac
#' @param n integer number of observations
#' @param beta vector true beta used to calculate y
#' @param rho double
#' @param pr probability of outlier ie y times -5 (default probability is 0.1)
#' @param fac the number to times the y values for outlier creation (default is -5)
#' @param intercept bool to include intercept (default is TRUE)
#' @param seed interger specifying the seed to use if NULL no seed is used (default is 6341)
#' @return  data.generate returns list of X and y
#'\item{X: matrix of nxp if no intercept and matrix of nx(p-1) for intercept}
#'\item{y: Vector of size n for generated response observations}
#' @examples
#' n <- 20; p <- 11; rho <- 0.5;
#' beta <-  c(seq(0,1,.2),rep(0,p-length(seq(0,1,.2))))
#' data.generate(n = n,beta = beta,rho = rho)
#'

data.generate <- function(n, beta, rho,pr=0.1,fac = -5,intercept = TRUE,seed = 6341){
  if(!is.null(seed)) {
    set.seed(seed)
  }

  if(intercept) {
    p <- length(beta)
    Sigma <- rho^abs(outer(1:(p-1),1:(p-1),"-"))
    X <- mvtnorm::rmvnorm(n, rep(0, p-1), Sigma)
    factor <- 2*stats::rbinom(n, size = 1, prob = 1-pr)-1
    factor[factor == -1] <- fac
    y <- factor * (cbind(1,X) %*% beta) + rnorm(n)
  }
  else {
    p <- length(beta)
    Sigma <- rho^abs(outer(1:(p),1:(p),"-"))
    X <- mvtnorm::rmvnorm(n, rep(0, p), Sigma)
    factor <- 2*stats::rbinom(n, size = 1, prob = 1-pr)-1
    y <- factor * (X %*% beta) + rnorm(n)
  }
  return(list(X = X, y = y))
}












