#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

// [[Rcpp::export]]
arma::vec cdhubercpp(arma::mat X,arma::vec y,arma::mat W,double M, double lambda, arma::vec beta, bool lasso,bool intercept,arma::vec resid,int maxiter,double tol,bool trace) {
  const int n = X.n_rows;
  const int p = X.n_cols;
  double R;
  arma::uvec id;
  double loss = 0;
  double loss0 = 0;


  int t = 0;

  for(int k = 0 ; k < maxiter; k++) {
    if( k == 0) {
      resid = y - X * beta;
    }

    for(int i = 0; i < n; i++){
      if(abs(resid(i)) <= M){
        W(i,i) = 1;
      }
      else {
        W(i,i) = M/abs(resid(i));
      }
    }

    if (lasso) {
      if (intercept) {
        beta(0) = mean(y - X.submat(0,1,n-1,p-1) * beta.subvec(1, p-1));
        t = 1;
      }
      for(int i = t; i<p; i++) {
        id = find(arma::linspace(0, p-1 , p) != i);
        R = as_scalar((trans(y - X.cols(id) * beta.elem(id)) * W * X.col(i)))/n;

        if( R > lambda) {
          beta(i) = (R  - lambda )/ (as_scalar((trans(X.col(i)) * W * X.col(i)))/n);
        }
        else if (R < -lambda){

          beta(i) = (R  + lambda )/ (as_scalar((trans(X.col(i)) * W * X.col(i)))/n);
        }
        else {
          beta(i) = 0;
        }
      }
    }
    else {
      for(int i = t; i<p; i++) {
        id = find(arma::linspace(0, p-1 , p) != i);
        R = as_scalar((trans(y - X.cols(id) * beta.elem(id)) * W * X.col(i)))/n;
        beta(i) = R / (as_scalar((trans(X.col(i)) * W * X.col(i)))/n);
      }
    }
    resid = y - X * beta;
    loss = 0;
    for (int i = 0; i < n ; i++) {
      if(abs(resid(i)) <= M){
        loss = loss + pow(resid(i),2);
      }
      else {
        loss = loss + (2 * M * abs(resid(i)) - pow(M,2));
      }
    }

    if(abs(loss - loss0) < tol){
      if(trace){
        Rcpp::Rcout << "Converged at Iteration = " << k << " loss = " << loss << "\\n";
      }
      break;
    }

    if(k == (maxiter-1)){
      Rcpp::Rcout << "Did not converge at interation" << k + 1 <<"\\n";
      Rcpp::stop("Did not converge at step ", maxiter, "\\n");
    }
    loss0 = loss;

  }


  return(beta);
}

// [[Rcpp::export]]
arma::vec resids(arma::mat X,arma::vec y,arma::vec beta) {
  return(y - X * beta);
}

// [[Rcpp::export]]
double lossc(arma::vec resid,double M) {
  const int n = resid.n_elem;
  double loss = 0;
  for (int i = 0; i < n ; i++) {
    if(abs(resid(i)) <= M){
      loss = loss + pow(resid(i),2);
    }
    else {
      loss = loss + (2 * M * abs(resid(i)) - pow(M,2));
    }
  }
  return(loss);
}

// [[Rcpp::export]]
arma::mat weightc(arma::vec resid,double M) {
  const int n = resid.n_elem;
  arma::mat W = arma::mat(n,n,arma::fill::eye);

  for(int i = 0; i < n; i++){
    if(abs(resid(i)) <= M){
      W(i,i) = 1;
    }
    else {
      W(i,i) = M/abs(resid(i));
    }
  }
  return(W);
}

